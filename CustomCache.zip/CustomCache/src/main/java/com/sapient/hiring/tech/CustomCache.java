package com.sapient.hiring.tech;

public class CustomCache<K, V> {

    public CustomCache(){
    }

    public void put(K key, V value){
        //TODO implement this method
    }

    public boolean remove(K key){
        //TODO implement this method
        return false;
    }


    public V get(K key){
        //TODO implement this method
        return null;
    }


}